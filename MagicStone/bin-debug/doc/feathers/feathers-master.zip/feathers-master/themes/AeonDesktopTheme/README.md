# Aeon Desktop Theme for Feathers

This [Feathers](http://feathersui.com/) theme for desktop is based on the theme used by the Flash Professional and the Flex MX component sets.

## Credits

The Aeon theme is originally designed by Adobe Systems Incorporated. Contains modifications by [Josh Tynjala](http://twitter.com/joshtynjala).