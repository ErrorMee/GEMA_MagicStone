# MXML Example for Feathers

A very simple example that uses MXML with the [Feathers](http://feathersui.com/) open source UI components library.